const http = require('http');
const express = require('express')
const api = express() ; 
const port = 3000
api.use(express.json())

// Available Routes
api.use('/api/player', require('./player'))
api.listen(port, () => {
  console.log(`Listening at http://localhost:${port}`)
})