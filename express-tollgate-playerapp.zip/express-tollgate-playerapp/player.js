const express = require("express");
const app = express.Router();
const bodyParser = require('body-parser');
const User = require("./db/userModel");
const dbConnect = require("./db/dbConnect");

dbConnect();

app.post("/", (req, res) =>{
    const user = new User({
        name: req.body.name,
        teamid: req.body.teamid,
      });

      user.save()
        .then((result) => {
          res.status(201).send({
            message: "User Created Successfully",
            result,
          });
        })
        .catch((error) => {
          res.status(500).send({
            message: "Error creating user",
            error,
          });
        });
})


module.exports = app;
