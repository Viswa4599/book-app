## Objective
**Complete the given ExpressJS Application for Player Management**
  - The Application is based on creating, reading, updating & deleting the Players
  - All data should persist in MongoDB database
  - It should use mongoose to communicate with MongoDB Database
  - The project is suggested to have a descriptive folder structure.

### Following are the broad tasks:
- Create a Player Model
- Create a Player Controller
- Create a Player Router

### API endpoints to be provided
| HTTP Method  | path                                     | Description                                         |
|--------------|------------------------------------------|-----------------------------------------------------|
| GET          | /api/player/{id}                         | Get an player by player id                            | 
| POST         | /api/player                              | Create a new player                                  |
| GET          | /api/player/team/{id}                  | Get all player for given team id                  |
| PUT          | /api/player                              | Update the player status                             |
| DELETE       | /api/player/{id}                         | Delete a player by player id                          |

### Important instructions for Participants
> - We expect you to write the assignment on your own by following through the guidelines/objectives.
> - The code must not be plagirized, the mentors will randomly pick the submissions and may ask you to explain the solution.
> - The code must be properly indented, code structure maintained as per the coding standards.
> - Complete the code as per the instructions in this document
> - Submit within the allotted time.

### MENTORS TO BEGIN REVIEW YOUR WORK ONLY AFTER ->
> - You add the respective Mentor as a Reporter into your Assignment Repository
