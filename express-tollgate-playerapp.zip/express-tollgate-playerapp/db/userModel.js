const mongoose = require("mongoose");
const PlayerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Please provide your first name!"],        
      },
    
      teamid: {
        type: Number,
        default : 0 // by default he wont be added to any team
      } , 
      
}) ;

module.exports = mongoose.model.Players || mongoose.model("Players", PlayerSchema);
