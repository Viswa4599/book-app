const mongoose = require("mongoose");
async function dbConnect() {
    mongoose
    .connect('mongodb+srv://book:book123@book.bgqt2dy.mongodb.net/?retryWrites=true&w=majority')
    .then(() => {
      console.log("Successfully connected to MongoDB Atlas!");
    })
    .catch((error) => {
      console.log("Unable to connect to MongoDB Atlas!");
      console.error(error);
    });
}

module.exports = dbConnect;